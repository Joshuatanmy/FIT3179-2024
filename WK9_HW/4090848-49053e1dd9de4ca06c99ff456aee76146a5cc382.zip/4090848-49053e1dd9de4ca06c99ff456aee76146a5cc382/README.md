This map demonstrates the [TopoJSON](https://github.com/topojson) [us-atlas](https://github.com/topojson/us-atlas). The same TopoJSON file can also be used to show [counties](/mbostock/4122298).
